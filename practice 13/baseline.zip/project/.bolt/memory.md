# Project memory

## Product intent & audience

- Smart Campus project — likely a room/resource booking or scheduling system for a university campus
- Part of coursework: Software Engineering Practice #08 (controlled defect reproduction + repair exercise)
- User is a student performing academic SE assignments

## Brand personality & voice

- Academic/technical reporting tone; structured evidence with tables and precise terminology
- Clear, direct, reproducible documentation style

## Visual design & UX direction

- No UI/visual design work involved this turn — purely backend logic and test verification
- (No visual context inferred yet beyond the vite-react + Tailwind + Lucide stack noted in `.bolt/prompt`)

## Decisions, constraints & rationale

- Test framework: Vitest (invoked via `npx vitest run`)
- Core logic lives in `src/lib/availability.ts`; overlap check is the single predicate controlling interval conflicts
- Original overlap condition (line 84): `if (start < booking.end && end > booking.start)` — strict inequalities mean touching endpoints are NOT conflicts
- BUG-A = changing strict `<` / `>` to `<=` / `>=` on that line, causing touching endpoints to be misclassified as overlaps
- BUG-B (not introduced) relates to mutating the bookings array; tests confirm no mutation occurs (T15)
- Controlled-defect workflow: copy original to `*.bugA.ts`, introduce only the target defect, add temporary test file `*.bugA.test.ts`, run, report — original stays untouched
- Tests are IDed (T01–T17); T01 and T08 cover touching-after and touching-before boundary cases
- Time represented as integer minutes (e.g., 600=10:00, 660=11:00, 720=12:00)
- AC4 acceptance criterion: intervals sharing only an endpoint must be allowed (no conflict)

## Open questions & assumptions

- No UI work has been requested yet; design/brand context still unseeded
- Whether to delete the temporary `*.bugA.*` files or keep them as evidence for the next assignment step is undecided
- Repair step deferred by user; expect a follow-up turn to revert BUG-A (or delete the copy) once evidence is captured
- Exact scope of the broader Smart Campus app beyond availability/booking logic is still unknown