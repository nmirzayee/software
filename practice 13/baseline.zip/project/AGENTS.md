# AGENTS.md

Instructions for AI coding agents working on the Smart Campus Room Availability Checker.

## 1. Project scope

- Maintain the Smart Campus Room Availability Checker: a React + TypeScript + Vite single-page app with a Supabase-backed bookings table.
- Preserve existing functionality and the acceptance criteria below. A change must not break them.
- Use fictional booking data only. Sample rooms and the current time are fictional by design.
- Do not introduce real personal information, real user data, or new production services.

### Acceptance criteria to preserve

1. Reject invalid or past times.
2. Enforce the allowed booking duration (maximum 120 minutes).
3. Reject overlapping bookings. Intervals that only touch at an endpoint are allowed.
4. Reject requests for blocked rooms.
5. Availability checks do not modify stored booking data.
6. Show clear availability feedback.
7. Support desktop and mobile layouts.

## 2. Repository map

- `src/App.tsx`: checker screen (room selection, time inputs, booking, cancellation).
- `src/components/AppRouter.tsx`: switches between the checker and the Risk Register using the URL hash.
- `src/components/RiskRegister.tsx`, `src/lib/riskRegister.ts`: Task 4 risk register page and its data.
- `src/components/Timeline.tsx`: visual day timeline.
- `src/lib/availability.ts`: core availability logic (`canBook`, time helpers).
- `src/lib/availability.test.ts`: unit tests for the core logic.
- `src/lib/availability.bugA.*`, `src/lib/availability.bugB.*`: controlled-defect evidence copies. Keep them unchanged unless a human asks otherwise.
- `src/lib/availability.ts.backup`: backup copy. Do not edit or delete.
- `src/lib/supabaseClient.ts`: Supabase client and row type.
- `src/sampleData.ts`: fictional rooms and current time.
- `supabase/migrations/`: database migration history.
- `dist/`: generated build output. Do not edit.

## 3. Allowed actions

- Read and inspect any file in the repository.
- Make small, task-related code changes when a human explicitly requests them.
- Run the safe commands listed in section 4.
- Add focused regression tests next to the code they cover when a change needs them.
- Update this file when a human asks for it.

## 4. Safe commands

These commands exist in `package.json`:

| Purpose | Command | Notes |
|---|---|---|
| Install dependencies | `npm ci` | Preferred. Uses `package-lock.json` exactly. |
| Lint | `npm run lint` | Runs `eslint .`. |
| Type check | `npm run typecheck` | Runs `tsc --noEmit -p tsconfig.app.json`. |
| Unit tests | `npm test` | Runs `vitest run`. |
| Build | `npm run build` | Runs `vite build` and regenerates `dist/`. |

Other rules for commands:

- Do not start a development server for verification. The environment does not support it.
- Do not run `npm run preview` unless a human asks.
- Do not run `npm install <package>` or `npm update`. Adding or upgrading packages needs human approval.
- Do not run the Supabase CLI. Use the Supabase tools that the platform provides, and only after the approval rules in sections 5 and 9.
- Report a command as passed only if you ran it and saw it pass.

## 5. Forbidden actions

- Never print, copy, log, or commit API keys, service keys, passwords, tokens, or environment variable values. Naming a variable is fine; showing its value is not.
- Never open or quote the contents of `.env` files.
- Never modify production database policies, roles, grants, or RLS settings.
- Never run destructive database commands (`DROP`, `TRUNCATE`, bulk `DELETE`, `ALTER` that removes or changes data).
- Never run migrations or change the database schema without explicit human approval.
- Never delete files, or rename or move them, unless a human explicitly asks.
- Never make unrelated refactors, formatting sweeps, or dependency changes inside a task.
- Never introduce new packages or external services without approval.
- Never change `.gitignore`, `package-lock.json`, or build and lint configuration unless the task is about that configuration.
- Never weaken a test, skip a check, or edit expected results to make a change pass.

## 6. Security and data rules

- The booking table currently allows anonymous reads, inserts, updates, and deletes. Treat that as a known risk. Do not add features that depend on it without a human decision.
- Booking titles are free text. Do not store, display, or log anything that looks like a real person's personal data.
- The Supabase anon key is public by design and ships with the browser code. It is still an environment value: do not print it in reports.
- Treat any database change as high risk. Propose the SQL in your report, and wait for explicit human approval before it is applied.

## 7. Testing requirements

Before you submit a change, run and report the results of:

1. `npm run lint`
2. `npm run typecheck`
3. `npm test`

Run `npm run build` when the change touches application code, components, or configuration.

For any change to availability logic, add or update a test in `src/lib/availability.test.ts` covering the affected acceptance criterion.

For any UI change, state clearly that the layout was not visually checked unless you actually viewed it.

## 8. Agent workflow

1. **Inspect before editing.** Read the files you will change and the tests that cover them.
2. **Make the smallest possible change** that satisfies the request.
3. **Verify the change** with the commands in section 7.
4. **Present evidence for human review:**
   - The reason for each change.
   - The complete diff of every changed file.
   - Each command you ran and its actual result.
   - Remaining risks and anything you could not verify.
5. **Stop and ask** before merging, deploying, changing the database, or changing anything listed in section 5.

## 9. Review and approval

- A human must review and approve every change before it is merged or deployed.
- A human must approve every database change, including migrations and policy edits, before it is applied.
- Agents must not claim a change is production-ready. They report what was verified and what was not.

## 10. Known risks and unverified behavior

- Overlap protection is enforced only in the browser. The database does not prevent overlapping bookings, so concurrent bookings can conflict.
- Blocked rooms are enforced only in the browser. The public API can still insert bookings for them.
- The checker's "now" uses a fixed fictional time, not the real clock.
- If the Supabase environment values are missing, the app may fail to load. This has not been run.
- There are no integration or UI tests. Visual layouts on phones and desktops are not verified automatically.
- Build status is not recorded in this document. Run `npm run build` before relying on the current build.
