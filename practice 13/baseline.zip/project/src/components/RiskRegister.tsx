import { AlertTriangle, ArrowLeft, Building2, Calculator, ShieldAlert } from 'lucide-react';
import {
  RISKS,
  TOP_RISK_IDS,
  priorityForScore,
  riskScore,
  type Risk,
  type RiskPriority,
} from '@/lib/riskRegister';

const PRIORITY_STYLES: Record<RiskPriority, string> = {
  Critical: 'bg-rose-100 text-rose-700 border-rose-200',
  High: 'bg-amber-100 text-amber-800 border-amber-200',
  Medium: 'bg-sky-100 text-sky-700 border-sky-200',
  Low: 'bg-teal-100 text-teal-700 border-teal-200',
};

const TOP_RISKS = TOP_RISK_IDS.map((id) => RISKS.find((r) => r.id === id)).filter(
  (r): r is Risk => r !== undefined,
);

function PriorityBadge({ priority }: { priority: RiskPriority }) {
  return (
    <span
      className={`inline-flex items-center text-[11px] font-semibold px-2 py-0.5 rounded-full border ${PRIORITY_STYLES[priority]}`}
    >
      {priority}
    </span>
  );
}

export default function RiskRegister() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-10 space-y-6 sm:space-y-8">
        <header className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3.5">
            <div className="flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 text-white shadow-lg shadow-slate-900/20">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-lg sm:text-2xl font-bold tracking-tight text-slate-900 leading-tight">
                Task 4 – Risk Register
              </h1>
              <p className="text-xs sm:text-sm text-slate-500 font-medium">
                Smart Campus Room Availability Checker
              </p>
            </div>
          </div>
          <a
            href="#"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white border border-slate-200 shadow-sm text-xs font-semibold text-slate-700 hover:border-slate-300 transition-colors"
          >
            <ArrowLeft className="w-3 h-3" />
            Back to checker
          </a>
        </header>

        <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-slate-400" />
            <h2 className="text-sm font-semibold text-slate-900">All risks</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-left text-sm">
              <thead className="bg-slate-50 text-xs font-semibold uppercase tracking-wide text-slate-500">
                <tr>
                  <th className="px-5 py-3 font-semibold">ID</th>
                  <th className="px-5 py-3 font-semibold">Category</th>
                  <th className="px-5 py-3 font-semibold">Risk</th>
                  <th className="px-5 py-3 font-semibold text-center">Likelihood</th>
                  <th className="px-5 py-3 font-semibold text-center">Impact</th>
                  <th className="px-5 py-3 font-semibold text-center">Score</th>
                  <th className="px-5 py-3 font-semibold">Priority</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {RISKS.map((risk) => {
                  const score = riskScore(risk);
                  const priority = priorityForScore(score);
                  return (
                    <tr key={risk.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-5 py-3.5 font-bold text-slate-900 whitespace-nowrap">{risk.id}</td>
                      <td className="px-5 py-3.5 text-slate-600 whitespace-nowrap">{risk.category}</td>
                      <td className="px-5 py-3.5 text-slate-800 font-medium">{risk.risk}</td>
                      <td className="px-5 py-3.5 text-center tabular-nums text-slate-700">{risk.likelihood}</td>
                      <td className="px-5 py-3.5 text-center tabular-nums text-slate-700">{risk.impact}</td>
                      <td className="px-5 py-3.5 text-center tabular-nums font-bold text-slate-900">{score}</td>
                      <td className="px-5 py-3.5">
                        <PriorityBadge priority={priority} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>

        <section className="space-y-3">
          <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-500" />
            Top Two Risks for Action
          </h2>
          <div className="grid gap-4 sm:grid-cols-2">
            {TOP_RISKS.map((risk, index) => (
              <article
                key={risk.id}
                className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 flex gap-4"
              >
                <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-slate-900 text-white text-sm font-bold shrink-0">
                  {index + 1}
                </div>
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-slate-500">
                    Priority {index + 1} · {risk.id}
                  </p>
                  <h3 className="text-base font-bold text-slate-900 mt-0.5">{risk.risk}</h3>
                  <div className="mt-2">
                    <PriorityBadge priority={priorityForScore(riskScore(risk))} />
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
          <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
            <Calculator className="w-4 h-4 text-slate-400" />
            How risks are scored
          </h2>
          <p className="mt-3 text-base font-bold text-slate-900 tabular-nums">
            Risk Score = Likelihood × Impact
          </p>
          <ul className="mt-3 grid gap-1.5 text-sm text-slate-600 sm:grid-cols-2">
            <li>Score 9: Critical</li>
            <li>Score 6: High</li>
            <li>Score 3–4: Medium</li>
            <li>Score 1–2: Low</li>
          </ul>
        </section>
      </div>
    </div>
  );
}
