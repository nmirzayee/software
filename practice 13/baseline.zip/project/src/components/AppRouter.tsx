import { useEffect, useState } from 'react';
import App from '@/App';
import RiskRegister from '@/components/RiskRegister';

const RISK_REGISTER_HASH = '#/risks';

export default function AppRouter() {
  const [hash, setHash] = useState(window.location.hash);

  useEffect(() => {
    const onHashChange = () => setHash(window.location.hash);
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  return hash === RISK_REGISTER_HASH ? <RiskRegister /> : <App />;
}
