import { minutesToLabel } from '@/lib/availability';
import type { Booking } from '@/sampleData';

interface TimelineProps {
  bookings: Booking[];
  candidateStart: number | null;
  candidateEnd: number | null;
  candidateAvailable: boolean | null;
  currentTime: number;
  blocked: boolean;
  highlightedIndex: number | null;
}

const HOUR_MARKS = Array.from({ length: 13 }, (_, i) => i * 2);
const MIN_TITLE_WIDTH_PCT = 8;
const MIN_TIME_WIDTH_PCT = 4;
const MIN_TIME_RANGE_WIDTH_PCT = 6.5;

export default function Timeline({
  bookings,
  candidateStart,
  candidateEnd,
  candidateAvailable,
  currentTime,
  blocked,
  highlightedIndex,
}: TimelineProps) {
  const pct = (min: number) => `${(min / 1440) * 100}%`;
  const widthPct = (s: number, e: number) => `${((e - s) / 1440) * 100}%`;

  const candidateColor =
    candidateAvailable === true
      ? 'bg-teal-400/30 border-teal-500'
      : candidateAvailable === false
        ? 'bg-rose-400/30 border-rose-500'
        : 'bg-sky-400/25 border-sky-400';

  return (
    <div className="w-full select-none">
      {/* Hour-axis labels */}
      <div className="relative h-5 mb-1.5">
        {HOUR_MARKS.map((h) => (
          <span
            key={h}
            className="absolute text-[10px] sm:text-[11px] text-slate-500 font-semibold -translate-x-1/2 tabular-nums whitespace-nowrap"
            style={{ left: pct(h) }}
          >
            {h === 24 ? '24:00' : `${String(h).padStart(2, '0')}:00`}
          </span>
        ))}
      </div>

      {/* Track */}
      <div className="relative h-16 rounded-xl bg-gradient-to-r from-slate-50 to-slate-100 border border-slate-200 overflow-hidden shadow-inner">
        {/* Grid lines */}
        {HOUR_MARKS.map((h) => (
          <div
            key={h}
            className="absolute top-0 bottom-0 w-px bg-slate-200/70"
            style={{ left: pct(h) }}
          />
        ))}

        {/* Existing bookings */}
        {bookings.map((b, i) => {
          const widthPctVal = ((b.end - b.start) / 1440) * 100;
          const showTitle = widthPctVal >= MIN_TITLE_WIDTH_PCT;
          const showTimeRange = widthPctVal >= MIN_TIME_RANGE_WIDTH_PCT;
          const showTimeOnly = widthPctVal >= MIN_TIME_WIDTH_PCT;
          const tooltip = `${b.title} (${minutesToLabel(b.start)}–${minutesToLabel(b.end)})`;
          const highlighted = highlightedIndex === i;

          return (
            <div
              key={b.id ?? i}
              tabIndex={0}
              role="button"
              aria-label={tooltip}
              title={tooltip}
              className={`absolute top-1.5 bottom-1.5 rounded-md flex flex-col items-center justify-center overflow-hidden cursor-pointer transition-all duration-200 ${
                highlighted
                  ? 'bg-indigo-600 ring-2 ring-indigo-400 ring-offset-1 scale-y-105 z-[6] shadow-md'
                  : 'bg-indigo-500/85 hover:bg-indigo-600 focus:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-400'
              }`}
              style={{ left: pct(b.start), width: widthPct(b.start, b.end) }}
            >
              <span className={`absolute top-0 left-0 px-1 text-[7px] sm:text-[8px] font-bold leading-none rounded-tl-md rounded-br-md ${highlighted ? 'bg-white/25 text-white' : 'bg-black/15 text-white/90'}`}>
                {i + 1}
              </span>
              <div className="flex flex-col items-center justify-center w-full h-full pt-1">
              {showTitle ? (
                <span className="text-[9px] sm:text-[10px] text-white font-semibold truncate max-w-full px-1 leading-none">
                  {b.title}
                </span>
              ) : showTimeOnly ? (
                <span className="text-[8px] sm:text-[9px] text-white/90 font-medium tabular-nums leading-none">
                  {minutesToLabel(b.start)}
                </span>
              ) : (
                <span className="w-1.5 h-1.5 rounded-full bg-white/90 shrink-0" />
              )}
              {showTimeRange && (
                <span className="text-[7px] sm:text-[8px] text-white/75 font-medium tabular-nums leading-none mt-0.5">
                  {minutesToLabel(b.start)}–{minutesToLabel(b.end)}
                </span>
              )}
              </div>
            </div>
          );
        })}

        {/* Candidate interval */}
        {candidateStart !== null && candidateEnd !== null && (
          <div
            className={`absolute top-0 bottom-0 border-2 rounded-md ${candidateColor} z-[5]`}
            style={{ left: pct(candidateStart), width: widthPct(candidateStart, candidateEnd) }}
          />
        )}

        {/* Current-time marker */}
        <div
          className="absolute top-0 bottom-0 w-0.5 bg-slate-900 z-10"
          style={{ left: pct(currentTime) }}
        >
          <span className="absolute -top-0.5 left-1/2 -translate-x-1/2 -translate-y-full text-[9px] text-white font-bold whitespace-nowrap bg-slate-900 px-1 py-0.5 rounded shadow-sm">
            Now
          </span>
        </div>

        {/* Blocked overlay */}
        {blocked && (
          <div className="absolute inset-0 bg-slate-500/40 backdrop-blur-[1px] flex items-center justify-center z-20">
            <span className="text-xs text-white font-bold tracking-wider uppercase drop-shadow">
              Blocked
            </span>
          </div>
        )}
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-x-4 gap-y-1.5 mt-3 text-[10px] text-slate-500">
        <span className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded bg-indigo-500/85" />
          Existing
        </span>
        <span className="flex items-center gap-1.5">
          <span className={`w-2.5 h-2.5 rounded border-2 ${candidateColor.split(' ')[0]} ${candidateColor.split(' ')[1]}`} />
          Your request
        </span>
        <span className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded bg-slate-900" />
          Now
        </span>
      </div>
    </div>
  );
}
