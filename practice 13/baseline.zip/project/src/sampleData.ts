// ═══════════════════════════════════════════════════════════════
// SAMPLE DATA — easy to inspect and adjust for testing
// All times are in minutes since midnight (0 = 00:00, 1440 = 24:00)
// ═══════════════════════════════════════════════════════════════

// Fictional "current time" for testing. Change this value to test scenarios.
//   540 = 09:00   720 = 12:00   900 = 15:00   1020 = 17:00
export const CURRENT_TIME = 540; // 09:00 AM

export interface Booking {
  id?: string;     // present when loaded from the database
  start: number;   // minutes since midnight
  end: number;
  title: string;
}

export interface Room {
  id: string;
  name: string;
  building: string;
  capacity: number;
  blocked: boolean;
  blockedReason?: string;
  bookings: Booking[]; // populated at runtime from the database
}

// Static room definitions — bookings are loaded from Supabase at runtime.
export const ROOMS: Room[] = [
  {
    id: 'eng-101',
    name: 'Engineering 101',
    building: 'Block A',
    capacity: 40,
    blocked: false,
    bookings: [],
  },
  {
    id: 'sci-204',
    name: 'Science 204',
    building: 'Block B',
    capacity: 25,
    blocked: false,
    bookings: [],
  },
  {
    id: 'lib-310',
    name: 'Library 310',
    building: 'Library Wing',
    capacity: 15,
    blocked: true,
    blockedReason: 'Under renovation until further notice',
    bookings: [],
  },
  {
    id: 'art-405',
    name: 'Arts 405',
    building: 'Arts Center',
    capacity: 30,
    blocked: false,
    bookings: [],
  },
];
