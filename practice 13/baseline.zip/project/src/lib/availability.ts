import type { Room } from '@/sampleData';

export interface AvailabilityResult {
  available: boolean;
  reason: string;
}

/** Convert minutes-since-midnight to an "HH:MM" label. */
export function minutesToLabel(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

/** Convert an "HH:MM" string to minutes since midnight. */
export function timeToMinutes(time: string): number {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
}

export interface BookingBooking {
  start: number;
  end: number;
  title: string;
}

export interface CanBookParams {
  start: number;
  end: number;
  now: number;
  blocked: boolean;
  bookings: BookingBooking[];
  blockedReason?: string;
}

/**
 * Evaluate a candidate booking against all acceptance criteria.
 * Does NOT modify existing booking data (AC5).
 */
export function canBook({
  start,
  end,
  now,
  blocked,
  bookings,
  blockedReason,
}: CanBookParams): AvailabilityResult {
  // AC1: 0 <= start < end <= 1440, start strictly after now
  if (Number.isNaN(start) || Number.isNaN(end)) {
    return { available: false, reason: 'Please enter valid start and end times.' };
  }
  if (start < 0 || end > 1440) {
    return { available: false, reason: 'Times must be within 00:00–24:00.' };
  }
  if (start >= end) {
    return { available: false, reason: 'Start time must be earlier than end time.' };
  }
  if (start <= now) {
    return {
      available: false,
      reason: `Start time must be strictly after the current time (${minutesToLabel(now)}).`,
    };
  }

  // AC2: reject bookings longer than 120 minutes
  const duration = end - start;
  if (duration > 120) {
    return {
      available: false,
      reason: `Booking duration is ${duration} min. The maximum allowed is 120 min.`,
    };
  }

  // AC3: reject when room is blocked
  if (blocked) {
    return {
      available: false,
      reason: `This room is blocked${blockedReason ? ': ' + blockedReason : '.'}`,
    };
  }

  // AC4: reject overlap with existing bookings (touching endpoints allowed)
  for (const booking of bookings) {
    if (start < booking.end && end > booking.start) {
      return {
        available: false,
        reason: `Overlaps with "${booking.title}" (${minutesToLabel(booking.start)}–${minutesToLabel(booking.end)}).`,
      };
    }
  }

  return {
    available: true,
    reason: `Available ${minutesToLabel(start)}–${minutesToLabel(end)} (${duration} min).`,
  };
}

/** Backward-compatible wrapper around canBook. */
export function checkAvailability(
  start: number,
  end: number,
  room: Room,
  currentTime: number,
): AvailabilityResult {
  return canBook({
    start,
    end,
    now: currentTime,
    blocked: room.blocked,
    bookings: room.bookings,
    blockedReason: room.blockedReason,
  });
}
