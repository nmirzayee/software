import { describe, it, expect } from 'vitest';
import { canBook } from './availability.bugA';
import type { CanBookParams } from './availability.bugA';

function makeInput(overrides: Partial<CanBookParams> = {}): CanBookParams {
  return {
    start: 660,
    end: 720,
    now: 540,
    blocked: false,
    bookings: [
      { start: 600, end: 660, title: 'Existing booking' },
    ],
    ...overrides,
  };
}

describe('Practice #08 — BUG-A reproduction (temporary copy)', () => {

  it('T01: touching after existing booking is available', () => {
    const result = canBook(makeInput({ start: 660, end: 720 }));
    expect(result.available).toBe(true);
    expect(result.reason).toMatch(/^Available 11:00–12:00 \(60 min\)\.$/);
  });

  it('T02: start equal to now is unavailable', () => {
    const result = canBook(makeInput({ start: 540, end: 570 }));
    expect(result.available).toBe(false);
    expect(result.reason).toMatch(/strictly after the current time/);
  });

  it('T03: zero duration (start == end) is unavailable', () => {
    const result = canBook(makeInput({ start: 720, end: 720 }));
    expect(result.available).toBe(false);
    expect(result.reason).toBe('Start time must be earlier than end time.');
  });

  it('T04: reversed times (start > end) is unavailable', () => {
    const result = canBook(makeInput({ start: 750, end: 720 }));
    expect(result.available).toBe(false);
    expect(result.reason).toBe('Start time must be earlier than end time.');
  });

  it('T05: end past midnight (1441) is unavailable', () => {
    const result = canBook(makeInput({ start: 1380, end: 1441 }));
    expect(result.available).toBe(false);
    expect(result.reason).toBe('Times must be within 00:00–24:00.');
  });

  it('T06: exactly 120 minutes is available', () => {
    const result = canBook(makeInput({ start: 720, end: 840 }));
    expect(result.available).toBe(true);
    expect(result.reason).toMatch(/^Available 12:00–14:00 \(120 min\)\.$/);
  });

  it('T07: 121 minutes is unavailable', () => {
    const result = canBook(makeInput({ start: 720, end: 841 }));
    expect(result.available).toBe(false);
    expect(result.reason).toMatch(/maximum allowed is 120 min/);
  });

  it('T08: touching before existing booking is available', () => {
    const result = canBook(makeInput({ start: 570, end: 600 }));
    expect(result.available).toBe(true);
    expect(result.reason).toMatch(/^Available 09:30–10:00 \(30 min\)\.$/);
  });

  it('T09: partial overlap with existing booking is unavailable', () => {
    const result = canBook(makeInput({ start: 630, end: 690 }));
    expect(result.available).toBe(false);
    expect(result.reason).toMatch(/^Overlaps with "Existing booking" \(10:00–11:00\)\.$/);
  });

  it('T10: containing an existing booking is unavailable', () => {
    const result = canBook(makeInput({ start: 570, end: 690 }));
    expect(result.available).toBe(false);
    expect(result.reason).toMatch(/^Overlaps with "Existing booking" \(10:00–11:00\)\.$/);
  });

  it('T11: fully inside an existing booking is unavailable', () => {
    const result = canBook(makeInput({ start: 615, end: 645 }));
    expect(result.available).toBe(false);
    expect(result.reason).toMatch(/^Overlaps with "Existing booking" \(10:00–11:00\)\.$/);
  });

  it('T12: identical to existing booking is unavailable', () => {
    const result = canBook(makeInput({ start: 600, end: 660 }));
    expect(result.available).toBe(false);
    expect(result.reason).toMatch(/^Overlaps with "Existing booking" \(10:00–11:00\)\.$/);
  });

  it('T13: blocked room is unavailable even with valid times', () => {
    const result = canBook(makeInput({ blocked: true }));
    expect(result.available).toBe(false);
    expect(result.reason).toBe('This room is blocked.');
  });

  it('T14: overlapping times with no existing bookings is available', () => {
    const result = canBook(makeInput({ start: 630, end: 690, bookings: [] }));
    expect(result.available).toBe(true);
    expect(result.reason).toMatch(/^Available 10:30–11:30 \(60 min\)\.$/);
  });

  it('T15: bookings array unchanged after accepted and rejected requests', () => {
    const acceptedInput = makeInput({ start: 660, end: 720 });
    const acceptedBefore = structuredClone(acceptedInput.bookings);
    canBook(acceptedInput);
    expect(acceptedInput.bookings).toEqual(acceptedBefore);

    const rejectedInput = makeInput({ start: 630, end: 690 });
    const rejectedBefore = structuredClone(rejectedInput.bookings);
    canBook(rejectedInput);
    expect(rejectedInput.bookings).toEqual(rejectedBefore);
  });

  it('T16: 1380–1440 (end of day boundary) is available', () => {
    const result = canBook(makeInput({ start: 1380, end: 1440 }));
    expect(result.available).toBe(true);
    expect(result.reason).toMatch(/^Available 23:00–24:00 \(60 min\)\.$/);
  });

  it('T17: fitting between two non-overlapping bookings is available', () => {
    const result = canBook(makeInput({
      start: 720,
      end: 780,
      bookings: [
        { start: 600, end: 660, title: 'A' },
        { start: 840, end: 900, title: 'B' },
      ],
    }));
    expect(result.available).toBe(true);
    expect(result.reason).toMatch(/^Available 12:00–13:00 \(60 min\)\.$/);
  });

});
