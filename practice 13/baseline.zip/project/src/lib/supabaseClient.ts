import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface RoomBookingRow {
  id: string;
  room_id: string;
  start_min: number;
  end_min: number;
  title: string;
  created_at: string;
}
