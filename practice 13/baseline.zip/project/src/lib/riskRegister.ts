export type RiskPriority = 'Critical' | 'High' | 'Medium' | 'Low';

export interface Risk {
  id: string;
  category: string;
  risk: string;
  likelihood: number;
  impact: number;
}

export const RISKS: Risk[] = [
  {
    id: 'R1',
    category: 'Correctness',
    risk: 'False availability when booking data fails to load',
    likelihood: 2,
    impact: 3,
  },
  {
    id: 'R2',
    category: 'Reliability',
    risk: 'Double booking due to missing database protection',
    likelihood: 2,
    impact: 3,
  },
  {
    id: 'R3',
    category: 'Security / Correctness',
    risk: 'Blocked rooms can be booked through the API',
    likelihood: 2,
    impact: 3,
  },
  {
    id: 'R4',
    category: 'Security',
    risk: 'Anonymous users can update or delete bookings',
    likelihood: 2,
    impact: 3,
  },
  {
    id: 'R5',
    category: 'Reliability / Security',
    risk: 'Booking titles have no length restriction',
    likelihood: 2,
    impact: 2,
  },
];

export const TOP_RISK_IDS = ['R4', 'R2'] as const;

export function riskScore(risk: Risk): number {
  return risk.likelihood * risk.impact;
}

export function priorityForScore(score: number): RiskPriority {
  if (score >= 9) return 'Critical';
  if (score >= 6) return 'High';
  if (score >= 3) return 'Medium';
  return 'Low';
}
