import type { Room } from '@/sampleData';

export interface AvailabilityResult {
  available: boolean;
  reason: string;
}

/** Convert minutes-since-midnight to an "HH:MM" label. */
export function minutesToLabel(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

/** Convert an "HH:MM" string to minutes since midnight. */
export function timeToMinutes(time: string): number {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
}

export interface BookingBooking {
  start: number;
  end: number;
  title: string;
}

export interface CanBookParams {
  start: number;
  end: number;
  now: number;
  blocked: boolean;
  bookings: BookingBooking[];
  blockedReason?: string;
}

/**
 * TEMPORARY COPY for Practice #08 — contains ONLY BUG-B.
 * The overlap condition is correct (touching endpoints allowed),
 * but the function mutates the caller's bookings array.
 */
export function canBook({
  start,
  end,
  now,
  blocked,
  bookings,
  blockedReason,
}: CanBookParams): AvailabilityResult {
  if (Number.isNaN(start) || Number.isNaN(end)) {
    return { available: false, reason: 'Please enter valid start and end times.' };
  }
  if (start < 0 || end > 1440) {
    return { available: false, reason: 'Times must be within 00:00–24:00.' };
  }
  if (start >= end) {
    return { available: false, reason: 'Start time must be earlier than end time.' };
  }
  if (start <= now) {
    return {
      available: false,
      reason: `Start time must be strictly after the current time (${minutesToLabel(now)}).`,
    };
  }

  const duration = end - start;
  if (duration > 120) {
    return {
      available: false,
      reason: `Booking duration is ${duration} min. The maximum allowed is 120 min.`,
    };
  }

  if (blocked) {
    return {
      available: false,
      reason: `This room is blocked${blockedReason ? ': ' + blockedReason : '.'}`,
    };
  }

  // AC4: overlap check (correct strict inequalities — touching endpoints allowed)
  for (const booking of bookings) {
    if (start < booking.end && end > booking.start) {
      return {
        available: false,
        reason: `Overlaps with "${booking.title}" (${minutesToLabel(booking.start)}–${minutesToLabel(booking.end)}).`,
      };
    }
  }

  return {
    available: true,
    reason: `Available ${minutesToLabel(start)}–${minutesToLabel(end)} (${duration} min).`,
  };
}

export function checkAvailability(
  start: number,
  end: number,
  room: Room,
  currentTime: number,
): AvailabilityResult {
  return canBook({
    start,
    end,
    now: currentTime,
    blocked: room.blocked,
    bookings: room.bookings,
    blockedReason: room.blockedReason,
  });
}
