import type { AvailabilityResult } from '@/lib/availability';

/**
 * Mock LLM adapter for explaining availability results.
 * Kept fully separate from the deterministic checker (availability.ts),
 * which remains the only source of truth. The adapter only describes a
 * result — it can never create, edit, or delete bookings.
 */

export type ReasonCode =
  | 'NO_CONFLICT'
  | 'OVERLAP'
  | 'ROOM_BLOCKED'
  | 'DURATION_EXCEEDED'
  | 'PAST_TIME'
  | 'INVALID_TIME';

export interface ExplainAvailabilityInput {
  roomLabel: string;
  startTime: string;
  endTime: string;
  isAvailable: boolean;
  reasonCode: ReasonCode;
}

export interface ExplanationResult {
  explanation: string;
}

export type ExplainAdapter = (input: ExplainAvailabilityInput) => Promise<ExplanationResult>;

export class ExplanationValidationError extends Error {
  code: 'INVALID_INPUT' | 'INVALID_OUTPUT';

  constructor(code: 'INVALID_INPUT' | 'INVALID_OUTPUT', message: string) {
    super(message);
    this.code = code;
  }
}

const TIME_PATTERN = /^([01]\d|2[0-4]):[0-5]\d$/;
const MAX_ROOM_LABEL_LENGTH = 80;
const MAX_EXPLANATION_LENGTH = 400;
const MAX_SENTENCES = 2;
const DEFAULT_TIMEOUT_MS = 2000;

const REASON_BECAUSE: Record<ReasonCode, string> = {
  NO_CONFLICT: 'no booking conflicts were found',
  OVERLAP: 'it overlaps an existing booking',
  ROOM_BLOCKED: 'the room is blocked',
  DURATION_EXCEEDED: 'the requested duration exceeds the 120-minute limit',
  PAST_TIME: 'the start time is not after the current time',
  INVALID_TIME: 'the time period is invalid',
};

/** Map a deterministic checker result to a reason code (never the other way). */
export function reasonCodeFromResult(result: AvailabilityResult): ReasonCode {
  if (result.available) return 'NO_CONFLICT';
  if (/overlaps/i.test(result.reason)) return 'OVERLAP';
  if (/blocked/i.test(result.reason)) return 'ROOM_BLOCKED';
  if (/duration|maximum allowed/i.test(result.reason)) return 'DURATION_EXCEEDED';
  if (/current time/i.test(result.reason)) return 'PAST_TIME';
  return 'INVALID_TIME';
}

function timeToMinutes(time: string): number {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
}

/** Throws ExplanationValidationError (INVALID_INPUT) when input is malformed. */
export function validateInput(raw: ExplainAvailabilityInput): ExplainAvailabilityInput {
  const roomLabel = typeof raw.roomLabel === 'string' ? raw.roomLabel.trim() : '';
  if (!roomLabel) {
    throw new ExplanationValidationError('INVALID_INPUT', 'Room label must not be empty.');
  }
  if (roomLabel.length > MAX_ROOM_LABEL_LENGTH) {
    throw new ExplanationValidationError(
      'INVALID_INPUT',
      `Room label must be at most ${MAX_ROOM_LABEL_LENGTH} characters.`,
    );
  }
  if (!TIME_PATTERN.test(raw.startTime ?? '') || !TIME_PATTERN.test(raw.endTime ?? '')) {
    throw new ExplanationValidationError('INVALID_INPUT', 'Times must use the HH:MM format.');
  }
  if (timeToMinutes(raw.startTime) >= timeToMinutes(raw.endTime)) {
    throw new ExplanationValidationError('INVALID_INPUT', 'Start time must be earlier than end time.');
  }
  if (!REASON_BECAUSE[raw.reasonCode]) {
    throw new ExplanationValidationError('INVALID_INPUT', 'Unknown reason code.');
  }
  return { ...raw, roomLabel };
}

/** Sentence count using terminal punctuation followed by whitespace/end. */
function countSentences(text: string): number {
  return text.split(/[.!?]+(?:\s|$)/).filter((s) => s.trim().length > 0).length;
}

function agreesWithResult(text: string, isAvailable: boolean): boolean {
  const saysUnavailable = /\bnot available\b|\bunavailable\b/i.test(text);
  const saysAvailable = /\bavailable\b/i.test(text) && !saysUnavailable;
  return isAvailable ? saysAvailable : saysUnavailable;
}

/** Throws ExplanationValidationError (INVALID_OUTPUT) when output is unusable or contradictory. */
export function validateExplanation(text: unknown, input: ExplainAvailabilityInput): string {
  if (typeof text !== 'string') {
    throw new ExplanationValidationError('INVALID_OUTPUT', 'Explanation must be a string.');
  }
  const trimmed = text.trim();
  if (!trimmed) {
    throw new ExplanationValidationError('INVALID_OUTPUT', 'Explanation must not be empty.');
  }
  if (trimmed.length > MAX_EXPLANATION_LENGTH) {
    throw new ExplanationValidationError('INVALID_OUTPUT', 'Explanation is too long.');
  }
  if (countSentences(trimmed) > MAX_SENTENCES) {
    throw new ExplanationValidationError('INVALID_OUTPUT', 'Explanation must be at most two sentences.');
  }
  if (!agreesWithResult(trimmed, input.isAvailable)) {
    throw new ExplanationValidationError('INVALID_OUTPUT', 'Explanation contradicts the availability result.');
  }
  return trimmed;
}

export function buildMockExplanation(input: ExplainAvailabilityInput): string {
  const because = REASON_BECAUSE[input.reasonCode];
  const availability = input.isAvailable ? 'is available' : 'is not available';
  return `${input.roomLabel} ${availability} from ${input.startTime} to ${input.endTime} because ${because}.`;
}

/**
 * Mock adapter: deterministic, no API key, no network. Sufficiently slow to
 * demonstrate the loading state. A real LLM adapter can replace it by
 * implementing the same ExplainAdapter signature.
 */
export const mockExplainAdapter: ExplainAdapter = async (input) => {
  await new Promise((resolve) => setTimeout(resolve, 120));
  if (/\[fail\]/i.test(input.roomLabel)) {
    throw new Error('Mock adapter failure (room label contains [fail])');
  }
  return { explanation: buildMockExplanation(input) };
};

function buildFallbackExplanation(input: ExplainAvailabilityInput): string {
  return buildMockExplanation(input);
}

/**
 * Validate input, call the adapter with a timeout, validate the response,
 * and fall back to a safe deterministic explanation on any failure.
 * Never throws for adapter problems — invalid input still throws.
 */
export async function explainAvailability(
  rawInput: ExplainAvailabilityInput,
  adapter: ExplainAdapter = mockExplainAdapter,
  timeoutMs: number = DEFAULT_TIMEOUT_MS,
): Promise<{ explanation: string; fallback: boolean }> {
  const input = validateInput(rawInput);

  try {
    const result = await Promise.race([
      adapter(input),
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error('Adapter timed out')), timeoutMs),
      ),
    ]);
    const explanation = validateExplanation(result?.explanation, input);
    return { explanation, fallback: false };
  } catch {
    return { explanation: buildFallbackExplanation(input), fallback: true };
  }
}
