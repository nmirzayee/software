/*
# Create room_bookings table (single-tenant, no auth)

## Purpose
Stores room booking records for the Smart Campus Room Availability Checker.
Each booking captures which room was booked, the time interval (in minutes
since midnight), a title, and a creation timestamp.

## New Tables
- `room_bookings`
  - `id` (uuid, primary key, auto-generated)
  - `room_id` (text, not null) — references the fictional room IDs in the app
  - `start_min` (integer, not null) — start time in minutes since midnight (0–1440)
  - `end_min` (integer, not null) — end time in minutes since midnight (0–1440)
  - `title` (text, not null) — human-readable label for the booking
  - `created_at` (timestamptz, default now())

## Constraints
- `start_min` must be >= 0
- `end_min` must be <= 1440
- `start_min` must be < `end_min`
- `end_min - start_min` must be <= 120 (max 2-hour bookings)

## Indexes
- Index on `room_id` for fast room-specific lookups
- Composite index on `(room_id, start_min, end_min)` for overlap queries

## Security
- RLS enabled on `room_bookings`.
- All four CRUD policies (SELECT, INSERT, UPDATE, DELETE) use `TO anon, authenticated`
  with `USING (true)` / `WITH CHECK (true)` because this is a single-tenant,
  no-auth demo app where booking data is intentionally shared and public.
*/

CREATE TABLE IF NOT EXISTS room_bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id text NOT NULL,
  start_min integer NOT NULL CHECK (start_min >= 0),
  end_min integer NOT NULL CHECK (end_min <= 1440),
  title text NOT NULL,
  created_at timestamptz DEFAULT now(),
  CHECK (start_min < end_min),
  CHECK (end_min - start_min <= 120)
);

CREATE INDEX IF NOT EXISTS idx_room_bookings_room_id ON room_bookings (room_id);
CREATE INDEX IF NOT EXISTS idx_room_bookings_room_interval ON room_bookings (room_id, start_min, end_min);

ALTER TABLE room_bookings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_bookings" ON room_bookings;
CREATE POLICY "anon_select_bookings"
  ON room_bookings FOR SELECT
  TO anon, authenticated
  USING (true);

DROP POLICY IF EXISTS "anon_insert_bookings" ON room_bookings;
CREATE POLICY "anon_insert_bookings"
  ON room_bookings FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_bookings" ON room_bookings;
CREATE POLICY "anon_update_bookings"
  ON room_bookings FOR UPDATE
  TO anon, authenticated
  USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_bookings" ON room_bookings;
CREATE POLICY "anon_delete_bookings"
  ON room_bookings FOR DELETE
  TO anon, authenticated
  USING (true);
