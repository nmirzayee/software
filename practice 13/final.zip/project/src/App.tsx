import { useCallback, useEffect, useState } from 'react';
import {
  Building2,
  Clock3,
  Users,
  Lock,
  CheckCircle2,
  XCircle,
  CalendarClock,
  Search,
  Timer,
  MapPin,
  DoorOpen,
  Sparkles,
  Info,
  Plus,
  Trash2,
  Loader2,
  ShieldAlert,
} from 'lucide-react';
import { ROOMS, type Room, type Booking } from '@/sampleData';
import { useCurrentTime } from '@/hooks/useCurrentTime';
import {
  canBook,
  minutesToLabel,
  timeToMinutes,
  type AvailabilityResult,
} from '@/lib/availability';
import { supabase, type RoomBookingRow } from '@/lib/supabaseClient';
import {
  explainAvailability,
  reasonCodeFromResult,
} from '@/lib/explainAvailability';
import Timeline from '@/components/Timeline';

function rowToBooking(row: RoomBookingRow): Booking {
  return { id: row.id, start: row.start_min, end: row.end_min, title: row.title };
}

export default function App() {
  const currentTime = useCurrentTime();
  const [rooms, setRooms] = useState<Room[]>(ROOMS);
  const [selectedRoomId, setSelectedRoomId] = useState<string>(ROOMS[0].id);
  const [startTime, setStartTime] = useState('10:00');
  const [endTime, setEndTime] = useState('11:00');
  const [endOfDay, setEndOfDay] = useState(false);
  const [result, setResult] = useState<AvailabilityResult | null>(null);
  const [hoveredBooking, setHoveredBooking] = useState<number | null>(null);
  const [bookingTitle, setBookingTitle] = useState('');
  const [isBooking, setIsBooking] = useState(false);
  const [bookingError, setBookingError] = useState<string | null>(null);
  const [cancelingId, setCancelingId] = useState<string | null>(null);
  const [loadingBookings, setLoadingBookings] = useState(true);
  const [explanation, setExplanation] = useState<string | null>(null);
  const [explanationFallback, setExplanationFallback] = useState(false);
  const [explaining, setExplaining] = useState(false);

  const selectedRoom: Room = rooms.find((r) => r.id === selectedRoomId) ?? rooms[0];

  const loadBookings = useCallback(async () => {
    const { data, error } = await supabase
      .from('room_bookings')
      .select('*')
      .order('start_min', { ascending: true });

    if (error) {
      setBookingError('Could not load bookings from the database.');
      setLoadingBookings(false);
      return;
    }

    const rows = data as RoomBookingRow[];
    setRooms((prev) =>
      prev.map((room) => ({
        ...room,
        bookings: rows
          .filter((r) => r.room_id === room.id)
          .map(rowToBooking)
          .sort((a, b) => a.start - b.start),
      })),
    );
    setLoadingBookings(false);
  }, []);

  useEffect(() => {
    loadBookings();
  }, [loadBookings]);

  const startMin = startTime ? timeToMinutes(startTime) : NaN;
  const endMin = endOfDay ? 1440 : endTime ? timeToMinutes(endTime) : NaN;
  const duration = !Number.isNaN(startMin) && !Number.isNaN(endMin) ? endMin - startMin : null;

  const candidateStart = !Number.isNaN(startMin) ? startMin : null;
  const candidateEnd = !Number.isNaN(endMin) ? endMin : null;

  const durationWarn = duration !== null && (duration <= 0 || duration > 120);

  const handleCheck = () => {
    setBookingError(null);
    setExplanation(null);
    setExplanationFallback(false);
    setResult(canBook({
      start: startMin,
      end: endMin,
      now: currentTime,
      blocked: selectedRoom.blocked,
      bookings: selectedRoom.bookings,
      blockedReason: selectedRoom.blockedReason,
    }));
  };

  const handleExplain = async () => {
    if (!result || explaining) return;
    setExplaining(true);
    try {
      const { explanation: text, fallback } = await explainAvailability({
        roomLabel: selectedRoom.name,
        startTime: minutesToLabel(startMin),
        endTime: minutesToLabel(endMin),
        isAvailable: result.available,
        reasonCode: reasonCodeFromResult(result),
      });
      setExplanation(text);
      setExplanationFallback(fallback);
    } catch {
      setExplanation('Explanation is not available for this selection. Please check the room and times.');
      setExplanationFallback(true);
    } finally {
      setExplaining(false);
    }
  };

  const handleBook = async () => {
    if (!result?.available) return;
    const title = bookingTitle.trim() || `Booking ${minutesToLabel(startMin)}–${minutesToLabel(endMin)}`;

    setIsBooking(true);
    setBookingError(null);

    const { data, error } = await supabase
      .from('room_bookings')
      .insert({
        room_id: selectedRoom.id,
        start_min: startMin,
        end_min: endMin,
        title,
      })
      .select('*')
      .single();

    if (error) {
      setBookingError('Could not save the booking. It may have been taken by someone else — try checking again.');
      setIsBooking(false);
      return;
    }

    const newRow = data as RoomBookingRow;
    setRooms((prev) =>
      prev.map((room) =>
        room.id === selectedRoom.id
          ? {
              ...room,
              bookings: [...room.bookings, rowToBooking(newRow)].sort((a, b) => a.start - b.start),
            }
          : room,
      ),
    );

    setResult(null);
    setBookingTitle('');
    setIsBooking(false);
  };

  const handleCancel = async (bookingId: string) => {
    setCancelingId(bookingId);
    const { error } = await supabase.from('room_bookings').delete().eq('id', bookingId);

    if (error) {
      setBookingError('Could not cancel the booking. Please try again.');
      setCancelingId(null);
      return;
    }

    setRooms((prev) =>
      prev.map((room) => ({
        ...room,
        bookings: room.bookings.filter((b) => b.id !== bookingId),
      })),
    );
    setCancelingId(null);
  };

  const openCount = rooms.filter((r) => !r.blocked).length;
  const blockedCount = rooms.length - openCount;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      {/* Decorative background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-teal-200/30 rounded-full blur-3xl" />
        <div className="absolute top-1/2 -left-32 w-80 h-80 bg-sky-200/25 rounded-full blur-3xl" />
        <div className="absolute -bottom-32 right-1/3 w-72 h-72 bg-indigo-200/20 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-10">
        {/* ── Header ──────────────────────────────────────────── */}
        <header className="mb-6 sm:mb-8 animate-fade-in">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3.5">
              <div className="relative flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 text-white shadow-lg shadow-slate-900/20">
                <Building2 className="w-6 h-6" />
                <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-teal-400 rounded-full border-2 border-white" />
              </div>
              <div>
                <h1 className="text-lg sm:text-2xl font-bold tracking-tight text-slate-900 leading-tight">
                  Smart Campus
                </h1>
                <p className="text-xs sm:text-sm text-slate-500 font-medium">
                  Room Availability Checker
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white border border-slate-200 shadow-sm">
                <span className="w-2 h-2 rounded-full bg-teal-500" />
                <span className="text-xs font-semibold text-slate-700">{openCount} Open</span>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white border border-slate-200 shadow-sm">
                <Lock className="w-3 h-3 text-rose-500" />
                <span className="text-xs font-semibold text-slate-700">{blockedCount} Blocked</span>
              </div>
              <a
                href="#/risks"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white border border-slate-200 shadow-sm text-xs font-semibold text-slate-700 hover:border-slate-300 transition-colors"
              >
                <ShieldAlert className="w-3 h-3 text-amber-600" />
                Risk Register
              </a>
            </div>
          </div>

          <div className="mt-4 flex items-center gap-3 px-4 py-2.5 rounded-xl bg-gradient-to-r from-slate-900 to-slate-800 text-white shadow-lg shadow-slate-900/15">
            <Clock3 className="w-4 h-4 text-teal-400" />
            <span className="text-sm font-medium text-slate-300">Current time</span>
            <span className="text-sm font-bold tabular-nums text-white">{minutesToLabel(currentTime)}</span>
            <span className="ml-auto flex items-center gap-1.5 text-[11px] text-slate-400">
              <Sparkles className="w-3 h-3" />
              Bookings max 120 min
            </span>
          </div>
        </header>

        {/* ── Main grid ───────────────────────────────────────── */}
        <div className="grid lg:grid-cols-5 gap-4 sm:gap-6">
          {/* Left column — form */}
          <div className="lg:col-span-2 space-y-4 sm:space-y-5">
            {/* Room selection */}
            <section className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                  <span className="flex items-center justify-center w-5 h-5 rounded-full bg-slate-900 text-white text-[10px] font-bold">
                    1
                  </span>
                  Select a room
                </h2>
                <MapPin className="w-3.5 h-3.5 text-slate-300" />
              </div>

              <div className="space-y-2.5">
                {rooms.map((room) => {
                  const active = room.id === selectedRoomId;
                  return (
                    <button
                      key={room.id}
                      onClick={() => {
                        setSelectedRoomId(room.id);
                        setResult(null);
                        setBookingError(null);
                        setExplanation(null);
                      }}
                      className={`relative w-full text-left p-3.5 pl-4 rounded-xl border-2 transition-all duration-200 group overflow-hidden ${
                        active
                          ? 'border-slate-900 bg-slate-50 shadow-md shadow-slate-900/5'
                          : 'border-slate-200 hover:border-slate-300 bg-white hover:shadow-sm'
                      }`}
                    >
                      {active && (
                        <span className="absolute left-0 top-0 bottom-0 w-1 bg-slate-900" />
                      )}
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div
                            className={`flex items-center justify-center w-9 h-9 rounded-lg shrink-0 transition-colors ${
                              active
                                ? 'bg-slate-900 text-white'
                                : room.blocked
                                  ? 'bg-rose-50 text-rose-400'
                                  : 'bg-slate-100 text-slate-400 group-hover:bg-slate-200'
                            }`}
                          >
                            {room.blocked ? <Lock className="w-4 h-4" /> : <DoorOpen className="w-4 h-4" />}
                          </div>
                          <div className="min-w-0">
                            <div className="text-sm font-semibold text-slate-800 truncate leading-tight">
                              {room.name}
                            </div>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className="flex items-center gap-0.5 text-[11px] text-slate-400">
                                <Building2 className="w-2.5 h-2.5" />
                                {room.building}
                              </span>
                              <span className="text-slate-300">·</span>
                              <span className="flex items-center gap-0.5 text-[11px] text-slate-400">
                                <Users className="w-2.5 h-2.5" />
                                {room.capacity}
                              </span>
                            </div>
                          </div>
                        </div>
                        <span
                          className={`shrink-0 text-[10px] font-bold px-2 py-1 rounded-full ${
                            room.blocked
                              ? 'bg-rose-100 text-rose-600'
                              : 'bg-teal-100 text-teal-700'
                          }`}
                        >
                          {room.blocked ? 'Blocked' : 'Open'}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </section>

            {/* Time inputs */}
            <section className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                  <span className="flex items-center justify-center w-5 h-5 rounded-full bg-slate-900 text-white text-[10px] font-bold">
                    2
                  </span>
                  Choose a time
                </h2>
                <Clock3 className="w-3.5 h-3.5 text-slate-300" />
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1.5">
                    Start time
                  </label>
                  <input
                    type="time"
                    value={startTime}
                    onChange={(e) => {
                      setStartTime(e.target.value);
                      setResult(null);
                      setExplanation(null);
                    }}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm tabular-nums focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent transition-all bg-slate-50/50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1.5">
                    End time
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="time"
                      value={endTime}
                      disabled={endOfDay}
                      onChange={(e) => {
                        setEndTime(e.target.value);
                        setResult(null);
                        setExplanation(null);
                      }}
                      className={`flex-1 px-3.5 py-2.5 rounded-xl border text-sm tabular-nums focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent transition-all ${
                        endOfDay
                          ? 'bg-slate-100 text-slate-400 border-slate-200'
                          : 'border-slate-300 bg-slate-50/50'
                      }`}
                    />
                    {endOfDay && (
                      <span className="px-3.5 py-2.5 rounded-xl bg-slate-900 text-white text-sm font-bold tabular-nums whitespace-nowrap">
                        24:00
                      </span>
                    )}
                  </div>
                  <label className="flex items-center gap-2 mt-2.5 text-xs text-slate-500 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={endOfDay}
                      onChange={(e) => {
                        setEndOfDay(e.target.checked);
                        setResult(null);
                        setExplanation(null);
                      }}
                      className="w-3.5 h-3.5 rounded border-slate-300 text-slate-900 focus:ring-slate-900"
                    />
                    Until end of day (24:00)
                  </label>
                </div>

                {/* Duration preview */}
                {duration !== null && (
                  <div
                    className={`flex items-center gap-2 text-xs font-medium px-3.5 py-2.5 rounded-xl transition-colors ${
                      durationWarn
                        ? 'bg-amber-50 text-amber-700 border border-amber-200'
                        : 'bg-teal-50 text-teal-700 border border-teal-200'
                    }`}
                  >
                    <Timer className="w-3.5 h-3.5 shrink-0" />
                    {duration > 0
                      ? `Duration: ${duration} minutes${duration > 120 ? ' · exceeds 120 min max' : ''}`
                      : 'End time must be after start time'}
                  </div>
                )}

                {/* Check button */}
                <button
                  onClick={handleCheck}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3.5 rounded-xl bg-gradient-to-r from-slate-900 to-slate-800 text-white text-sm font-semibold hover:from-slate-800 hover:to-slate-700 active:scale-[0.98] transition-all shadow-lg shadow-slate-900/15"
                >
                  <Search className="w-4 h-4" />
                  Check Availability
                </button>
              </div>
            </section>
          </div>

          {/* Right column — info & results */}
          <div className="lg:col-span-3 space-y-4 sm:space-y-5">
            {/* Room detail + timeline */}
            <section className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="px-5 pt-5 pb-4 border-b border-slate-100">
                <div className="flex items-start justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-slate-100 to-slate-200 text-slate-600">
                      <DoorOpen className="w-5 h-5" />
                    </div>
                    <div>
                      <h2 className="text-base font-bold text-slate-900 leading-tight">
                        {selectedRoom.name}
                      </h2>
                      <div className="flex items-center gap-2.5 mt-1 text-xs text-slate-500">
                        <span className="flex items-center gap-1">
                          <Building2 className="w-3 h-3" />
                          {selectedRoom.building}
                        </span>
                        <span className="text-slate-300">·</span>
                        <span className="flex items-center gap-1">
                          <Users className="w-3 h-3" />
                          {selectedRoom.capacity} seats
                        </span>
                      </div>
                    </div>
                  </div>
                  <span
                    className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full ${
                      selectedRoom.blocked
                        ? 'bg-rose-100 text-rose-700'
                        : 'bg-teal-100 text-teal-700'
                    }`}
                  >
                    {selectedRoom.blocked ? (
                      <>
                        <Lock className="w-3.5 h-3.5" /> Blocked
                      </>
                    ) : (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" /> Open
                      </>
                    )}
                  </span>
                </div>

                {selectedRoom.blocked && selectedRoom.blockedReason && (
                  <p className="text-xs text-rose-600 bg-rose-50 rounded-lg px-3 py-2 mt-3 flex items-start gap-2">
                    <Info className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                    {selectedRoom.blockedReason}
                  </p>
                )}
              </div>

              <div className="px-5 py-4">
                {loadingBookings ? (
                  <div className="flex items-center justify-center h-20 text-slate-400">
                    <Loader2 className="w-5 h-5 animate-spin" />
                  </div>
                ) : (
                  <Timeline
                    bookings={selectedRoom.bookings}
                    candidateStart={candidateStart}
                    candidateEnd={candidateEnd}
                    candidateAvailable={result?.available ?? null}
                    currentTime={currentTime}
                    blocked={selectedRoom.blocked}
                    highlightedIndex={hoveredBooking}
                  />
                )}
              </div>
            </section>

            {/* Result + Book */}
            {result && (
              <section
                className={`rounded-2xl border-2 p-5 animate-slide-up ${
                  result.available
                    ? 'border-teal-200 bg-gradient-to-br from-teal-50 to-emerald-50'
                    : 'border-rose-200 bg-gradient-to-br from-rose-50 to-orange-50'
                }`}
              >
                <div className="flex items-start gap-3.5">
                  <div
                    className={`flex items-center justify-center w-10 h-10 rounded-xl shrink-0 ${
                      result.available
                        ? 'bg-teal-500 text-white shadow-lg shadow-teal-500/20'
                        : 'bg-rose-500 text-white shadow-lg shadow-rose-500/20'
                    }`}
                  >
                    {result.available ? (
                      <CheckCircle2 className="w-5 h-5" />
                    ) : (
                      <XCircle className="w-5 h-5" />
                    )}
                  </div>
                  <div className="flex-1 pt-0.5">
                    <h3
                      className={`text-base font-bold ${
                        result.available ? 'text-teal-800' : 'text-rose-800'
                      }`}
                    >
                      {result.available ? 'Available' : 'Unavailable'}
                    </h3>
                    <p
                      className={`text-sm mt-0.5 ${
                        result.available ? 'text-teal-700' : 'text-rose-700'
                      }`}
                    >
                      {result.reason}
                    </p>

                    {/* Explain Availability — mock AI, separate from the decision */}
                    <div className="mt-4 pt-4 border-t border-slate-200/60">
                      {!explanation && (
                        <button
                          onClick={handleExplain}
                          disabled={explaining}
                          className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-700 hover:border-slate-400 hover:bg-slate-50 active:scale-[0.98] transition-all disabled:opacity-60 disabled:cursor-not-allowed"
                        >
                          {explaining ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                          )}
                          {explaining ? 'Explaining…' : 'Explain Availability'}
                        </button>
                      )}
                      {explanation && (
                        <div className="rounded-xl bg-white/80 border border-slate-200 px-4 py-3 mt-1">
                          <div className="flex items-center justify-between gap-2 mb-1.5">
                            <span className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide text-slate-400">
                              <Sparkles className="w-3 h-3 text-amber-500" />
                              AI-generated explanation (mock)
                              {explanationFallback && (
                                <span className="font-semibold text-amber-600 normal-case tracking-normal">
                                  · fallback used
                                </span>
                              )}
                            </span>
                            <button
                              onClick={() => {
                                setExplanation(null);
                                setExplanationFallback(false);
                              }}
                              className="text-[10px] font-semibold text-slate-400 hover:text-slate-600 transition-colors"
                            >
                              Hide
                            </button>
                          </div>
                          <p className="text-sm text-slate-600 leading-relaxed">{explanation}</p>
                        </div>
                      )}
                    </div>

                    {/* Book form — only when available */}
                    {result.available && (
                      <div className="mt-4 flex flex-col sm:flex-row gap-2.5">
                        <input
                          type="text"
                          placeholder="Booking title (optional)"
                          value={bookingTitle}
                          onChange={(e) => setBookingTitle(e.target.value)}
                          className="flex-1 px-3.5 py-2.5 rounded-xl border border-teal-300 bg-white text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
                        />
                        <button
                          onClick={handleBook}
                          disabled={isBooking}
                          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-teal-600 text-white text-sm font-semibold hover:bg-teal-700 active:scale-[0.98] transition-all shadow-lg shadow-teal-600/20 disabled:opacity-60 disabled:cursor-not-allowed whitespace-nowrap"
                        >
                          {isBooking ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <Plus className="w-4 h-4" />
                          )}
                          {isBooking ? 'Booking...' : 'Book this slot'}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </section>
            )}

            {/* Booking error */}
            {bookingError && (
              <div className="rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700 flex items-center gap-2 animate-slide-up">
                <Info className="w-4 h-4 shrink-0" />
                {bookingError}
              </div>
            )}

            {/* Existing bookings */}
            <section className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5">
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                  <CalendarClock className="w-4 h-4 text-slate-400" />
                  Existing bookings
                  {selectedRoom.bookings.length > 0 && (
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-500">
                      {selectedRoom.bookings.length}
                    </span>
                  )}
                </h2>
                <span className="text-[10px] text-slate-400">Hover to highlight · Click trash to cancel</span>
              </div>
              {loadingBookings ? (
                <div className="flex items-center justify-center py-6 text-slate-400">
                  <Loader2 className="w-5 h-5 animate-spin" />
                </div>
              ) : selectedRoom.bookings.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-6 text-center">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-slate-50 mb-2">
                    <CalendarClock className="w-5 h-5 text-slate-300" />
                  </div>
                  <p className="text-sm text-slate-400">
                    No existing bookings for this room.
                  </p>
                </div>
              ) : (
                <ul className="space-y-2">
                  {selectedRoom.bookings.map((b, i) => (
                    <li
                      key={b.id ?? i}
                      onMouseEnter={() => setHoveredBooking(i)}
                      onMouseLeave={() => setHoveredBooking(null)}
                      onFocus={() => setHoveredBooking(i)}
                      onBlur={() => setHoveredBooking(null)}
                      tabIndex={0}
                      className={`flex items-center justify-between gap-3 px-3.5 py-3 rounded-xl border cursor-pointer transition-all duration-200 outline-none ${
                        hoveredBooking === i
                          ? 'bg-indigo-50 border-indigo-200 ring-2 ring-indigo-200 shadow-sm'
                          : 'bg-slate-50 border-slate-100 hover:bg-slate-100 hover:border-slate-200 focus:bg-indigo-50 focus:border-indigo-200 focus:ring-2 focus:ring-indigo-200'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <span
                          className={`flex items-center justify-center w-7 h-7 rounded-lg text-[11px] font-bold shrink-0 transition-colors ${
                            hoveredBooking === i
                              ? 'bg-indigo-600 text-white'
                              : 'bg-indigo-100 text-indigo-600'
                          }`}
                        >
                          {i + 1}
                        </span>
                        <span className="text-sm font-medium text-slate-700 truncate">
                          {b.title}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 tabular-nums whitespace-nowrap">
                          <Clock3 className="w-3 h-3 text-slate-300" />
                          {minutesToLabel(b.start)}–{minutesToLabel(b.end)}
                        </span>
                        {b.id && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleCancel(b.id!);
                            }}
                            disabled={cancelingId === b.id}
                            className="flex items-center justify-center w-7 h-7 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 transition-colors disabled:opacity-50"
                            title="Cancel this booking"
                          >
                            {cancelingId === b.id ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <Trash2 className="w-3.5 h-3.5" />
                            )}
                          </button>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </div>
        </div>

        <p className="text-center text-xs text-slate-400 mt-6 sm:mt-8">
          Bookings are saved and can be canceled. Sample rooms and current time are fictional.
        </p>
      </div>
    </div>
  );
}
