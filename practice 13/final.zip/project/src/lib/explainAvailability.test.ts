import { describe, expect, it } from 'vitest';
import {
  explainAvailability,
  ExplanationValidationError,
  reasonCodeFromResult,
  type ExplainAdapter,
  type ExplainAvailabilityInput,
} from './explainAvailability';

const base: Omit<ExplainAvailabilityInput, 'isAvailable' | 'reasonCode'> = {
  roomLabel: 'Room A101',
  startTime: '10:00',
  endTime: '11:00',
};

describe('Explain Availability (mock LLM adapter)', () => {
  it('scenario 1: explains an available room with no conflict', async () => {
    const { explanation, fallback } = await explainAvailability({
      ...base,
      isAvailable: true,
      reasonCode: 'NO_CONFLICT',
    });

    expect(fallback).toBe(false);
    expect(explanation).toBe(
      'Room A101 is available from 10:00 to 11:00 because no booking conflicts were found.',
    );
  });

  it('scenario 2: explains an unavailable room due to an overlapping booking', async () => {
    const { explanation, fallback } = await explainAvailability({
      ...base,
      isAvailable: false,
      reasonCode: 'OVERLAP',
    });

    expect(fallback).toBe(false);
    expect(explanation).toMatch(/not available/i);
    expect(explanation).toMatch(/overlaps/i);
  });

  it('scenario 3: rejects an invalid time format', async () => {
    await expect(
      explainAvailability({ ...base, startTime: '25:99', isAvailable: false, reasonCode: 'INVALID_TIME' }),
    ).rejects.toThrowError(ExplanationValidationError);
  });

  it('scenario 4: rejects empty input', async () => {
    await expect(
      explainAvailability({ ...base, roomLabel: '', isAvailable: true, reasonCode: 'NO_CONFLICT' }),
    ).rejects.toThrowError(ExplanationValidationError);

    await expect(
      explainAvailability({ ...base, startTime: '', endTime: '', isAvailable: true, reasonCode: 'NO_CONFLICT' }),
    ).rejects.toThrowError(ExplanationValidationError);
  });

  it('scenario 5: rejects a start time later than the end time', async () => {
    await expect(
      explainAvailability({
        ...base,
        startTime: '12:00',
        endTime: '10:00',
        isAvailable: false,
        reasonCode: 'INVALID_TIME',
      }),
    ).rejects.toThrowError(ExplanationValidationError);
  });

  it('scenario 6: rejects excessively long input', async () => {
    await expect(
      explainAvailability({
        ...base,
        roomLabel: 'A'.repeat(500),
        isAvailable: true,
        reasonCode: 'NO_CONFLICT',
      }),
    ).rejects.toThrowError(ExplanationValidationError);
  });

  it('scenario 7: falls back safely when the mock adapter fails', async () => {
    const { explanation, fallback } = await explainAvailability({
      ...base,
      roomLabel: 'Room [fail] A101',
      isAvailable: true,
      reasonCode: 'NO_CONFLICT',
    });

    expect(fallback).toBe(true);
    expect(explanation).toMatch(/Room \[fail\] A101 is available from 10:00 to 11:00/);
  });

  it('scenario 7b: falls back safely when the adapter times out', async () => {
    const slowAdapter: ExplainAdapter = () =>
      new Promise((resolve) => setTimeout(() => resolve({ explanation: 'too late' }), 500));

    const { explanation, fallback } = await explainAvailability(
      { ...base, isAvailable: true, reasonCode: 'NO_CONFLICT' },
      slowAdapter,
      20,
    );

    expect(fallback).toBe(true);
    expect(explanation).toMatch(/is available from 10:00 to 11:00/);
  });

  it('scenario 8: rejects an explanation that contradicts the availability result', async () => {
    const contradictingAdapter: ExplainAdapter = (input) =>
      Promise.resolve({
        explanation: `Room ${input.roomLabel} is available from 10:00 to 11:00, all clear!`,
      });

    const { explanation, fallback } = await explainAvailability(
      { ...base, isAvailable: false, reasonCode: 'OVERLAP' },
      contradictingAdapter,
    );

    expect(fallback).toBe(true);
    expect(explanation).toMatch(/not available/i);
  });

  it('rejects adapter output that is empty, non-string, too long, or over two sentences', async () => {
    const unavailable = { ...base, isAvailable: false, reasonCode: 'OVERLAP' } as const;
    const passing: ExplainAdapter = () => Promise.resolve({ explanation: 'x' });

    await expect(explainAvailability(unavailable, passing)).resolves.toMatchObject({ fallback: true });
    await expect(
      explainAvailability(unavailable, () => Promise.resolve({ explanation: undefined as unknown as string })),
    ).resolves.toMatchObject({ fallback: true });
    await expect(
      explainAvailability(
        unavailable,
        () => Promise.resolve({ explanation: `not available. ${'x'.repeat(500)}` }),
      ),
    ).resolves.toMatchObject({ fallback: true });
    await expect(
      explainAvailability(
        unavailable,
        () => Promise.resolve({ explanation: 'Not available. It overlaps. Also too much.' }),
      ),
    ).resolves.toMatchObject({ fallback: true });
  });

  it('never mutates the input (no booking or data modification)', async () => {
    const input: ExplainAvailabilityInput = {
      ...base,
      isAvailable: false,
      reasonCode: 'OVERLAP',
    };
    const snapshot = JSON.stringify(input);

    await explainAvailability(input);
    await explainAvailability(input, () =>
      Promise.resolve({ explanation: 'unexpected text' }),
    );

    expect(JSON.stringify(input)).toBe(snapshot);
  });

  it('maps deterministic checker results to reason codes', () => {
    expect(reasonCodeFromResult({ available: true, reason: 'Available 10:00–11:00 (60 min).', reasonCode: 'AVAILABLE' })).toBe('NO_CONFLICT');
    expect(reasonCodeFromResult({ available: false, reason: 'Overlaps with "x" (10:00–11:00).', reasonCode: 'BOOKING_OVERLAP' })).toBe('OVERLAP');
    expect(reasonCodeFromResult({ available: false, reason: 'This room is blocked: maintenance.', reasonCode: 'ROOM_BLOCKED' })).toBe(
      'ROOM_BLOCKED',
    );
    expect(reasonCodeFromResult({ available: false, reason: 'Booking duration is 130 min. The maximum allowed is 120 min.', reasonCode: 'INVALID_DURATION' })).toBe(
      'DURATION_EXCEEDED',
    );
    expect(reasonCodeFromResult({ available: false, reason: 'Start time must be strictly after the current time (12:00).', reasonCode: 'INVALID_START_TIME' })).toBe(
      'PAST_TIME',
    );
    expect(reasonCodeFromResult({ available: false, reason: 'Start time must be earlier than end time.', reasonCode: 'INVALID_DURATION' })).toBe(
      'INVALID_TIME',
    );
  });
});
