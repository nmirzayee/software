import type { Room } from '@/sampleData';

export type ReasonCode =
  | 'AVAILABLE'
  | 'INVALID_START_TIME'
  | 'INVALID_DURATION'
  | 'ROOM_BLOCKED'
  | 'BOOKING_OVERLAP';

export interface AvailabilityResult {
  available: boolean;
  reason: string;
  reasonCode: ReasonCode;
}

/** Convert minutes-since-midnight to an "HH:MM" label. */
export function minutesToLabel(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

/** Convert an "HH:MM" string to minutes since midnight. */
export function timeToMinutes(time: string): number {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
}

export interface BookingBooking {
  start: number;
  end: number;
  title: string;
}

export interface CanBookParams {
  start: number;
  end: number;
  now: number;
  blocked: boolean;
  bookings: BookingBooking[];
  blockedReason?: string;
}

interface Rejection {
  reasonCode: ReasonCode;
  reason: string;
}

/**
 * Input validation (AC1, AC2, AC6): time range, ordering, future start,
 * and duration limits. Pure — no availability logic here.
 * Returns a rejection or null when the input itself is well-formed.
 */
export function validateBookingInput(
  start: number,
  end: number,
  now: number,
): Rejection | null {
  if (Number.isNaN(start) || Number.isNaN(end)) {
    return {
      reasonCode: 'INVALID_START_TIME',
      reason: 'Please enter valid start and end times.',
    };
  }
  if (start < 0 || end > 1440) {
    return {
      reasonCode: 'INVALID_START_TIME',
      reason: 'Times must be within 00:00–24:00.',
    };
  }
  const duration = end - start;
  if (duration < 1) {
    return {
      reasonCode: 'INVALID_DURATION',
      reason: 'Start time must be earlier than end time.',
    };
  }
  if (start <= now) {
    return {
      reasonCode: 'INVALID_START_TIME',
      reason: `Start time must be strictly after the current time (${minutesToLabel(now)}).`,
    };
  }
  if (duration > 120) {
    return {
      reasonCode: 'INVALID_DURATION',
      reason: `Booking duration is ${duration} min. The maximum allowed is 120 min.`,
    };
  }
  return null;
}

/**
 * Availability calculation (AC3, AC4): blocked rooms and overlap detection.
 * Pure — reads bookings but never modifies them (AC5).
 * Touching endpoints are allowed: (start < booking.end) AND (end > booking.start).
 */
export function evaluateAvailability(
  start: number,
  end: number,
  blocked: boolean,
  bookings: BookingBooking[],
  blockedReason?: string,
): AvailabilityResult {
  if (blocked) {
    return {
      available: false,
      reasonCode: 'ROOM_BLOCKED',
      reason: `This room is blocked${blockedReason ? ': ' + blockedReason : '.'}`,
    };
  }
  for (const booking of bookings) {
    if (start < booking.end && end > booking.start) {
      return {
        available: false,
        reasonCode: 'BOOKING_OVERLAP',
        reason: `Overlaps with "${booking.title}" (${minutesToLabel(booking.start)}–${minutesToLabel(booking.end)}).`,
      };
    }
  }
  return {
    available: true,
    reasonCode: 'AVAILABLE',
    reason: `Available ${minutesToLabel(start)}–${minutesToLabel(end)} (${end - start} min).`,
  };
}

/**
 * Evaluate a candidate booking against all acceptance criteria:
 * validation first, then availability calculation.
 * Does NOT modify existing booking data (AC5).
 */
export function canBook({
  start,
  end,
  now,
  blocked,
  bookings,
  blockedReason,
}: CanBookParams): AvailabilityResult {
  const rejection = validateBookingInput(start, end, now);
  if (rejection) {
    return { available: false, reasonCode: rejection.reasonCode, reason: rejection.reason };
  }
  return evaluateAvailability(start, end, blocked, bookings, blockedReason);
}

/** Backward-compatible wrapper around canBook. */
export function checkAvailability(
  start: number,
  end: number,
  room: Room,
  currentTime: number,
): AvailabilityResult {
  return canBook({
    start,
    end,
    now: currentTime,
    blocked: room.blocked,
    bookings: room.bookings,
    blockedReason: room.blockedReason,
  });
}
