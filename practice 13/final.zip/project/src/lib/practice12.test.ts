import { describe, expect, it } from 'vitest';
import { canBook, type BookingBooking, type CanBookParams } from './availability';

/**
 * Practice 12 — Task 02: eight required test cases against a dedicated,
 * deterministic fixture. Reuses the project's real checker (canBook) and the
 * fictional room "Engineering 101" (eng-101) from src/sampleData.ts, but does
 * not touch application data or the database.
 */

const TEST_NOW = 9 * 60; // 09:00 test clock

const FIXTURE_BOOKINGS: BookingBooking[] = [
  { start: 600, end: 660, title: 'Study group session' },  // 10:00–11:00
  { start: 780, end: 840, title: 'Seminar practice' },     // 13:00–14:00
];

function makeInput(overrides: Partial<CanBookParams> = {}): CanBookParams {
  return {
    start: 690,          // 11:30
    end: 720,            // +30 min
    now: TEST_NOW,
    blocked: false,
    bookings: FIXTURE_BOOKINGS,
    ...overrides,
  };
}

function run(start: number, duration: number, blocked = false) {
  return canBook(makeInput({ start, end: start + duration, blocked }));
}

describe('Practice 12 — Task 02: eight required test cases', () => {
  it('T1: start 11:30, duration 30, room not blocked — available', () => {
    const result = run(690, 30);
    expect(result.available).toBe(true);
    expect(result.reason).toMatch(/Available 11:30–12:00 \(30 min\)/);
  });

  it('T2: start 10:30, duration 30 — unavailable due to overlap', () => {
    const result = run(630, 30);
    expect(result.available).toBe(false);
    expect(result.reason).toMatch(/Overlaps with "Study group session" \(10:00–11:00\)/);
  });

  it('T3: start 11:30, duration 30, room blocked — unavailable', () => {
    const result = run(690, 30, true);
    expect(result.available).toBe(false);
    expect(result.reason).toMatch(/blocked/);
  });

  it('T4: duration 0 — validation error', () => {
    const result = run(690, 0);
    expect(result.available).toBe(false);
    expect(result.reason).toMatch(/earlier than end time/);
  });

  it('T5: duration 121 — validation error', () => {
    const result = run(690, 121);
    expect(result.available).toBe(false);
    expect(result.reason).toMatch(/maximum allowed is 120 min/);
  });

  it('T6: start 08:30 before current time 09:00 — validation error', () => {
    const result = run(510, 30);
    expect(result.available).toBe(false);
    expect(result.reason).toMatch(/strictly after the current time \(09:00\)/);
  });

  it('T7: start 11:00 adjacent to a booking ending 11:00 — available', () => {
    const result = run(660, 30);
    expect(result.available).toBe(true);
    expect(result.reason).toMatch(/Available 11:00–11:30 \(30 min\)/);
  });

  it('T8: availability check leaves existing booking data unchanged', () => {
    const input = makeInput();
    const before = structuredClone(input.bookings);
    canBook(input);
    canBook(makeInput({ start: 630, end: 660 })); // a rejected case too
    expect(input.bookings).toEqual(before);
  });
});
