import { useEffect, useState } from 'react';

function currentMinutes(): number {
  const d = new Date();
  return d.getHours() * 60 + d.getMinutes();
}

/**
 * Real wall-clock time in minutes since midnight, refreshed every 30 s.
 * The app uses this for checks and display; automated tests pass their own
 * deterministic `now` instead of relying on this hook.
 */
export function useCurrentTime(): number {
  const [now, setNow] = useState(currentMinutes);

  useEffect(() => {
    const id = setInterval(() => setNow(currentMinutes()), 30_000);
    return () => clearInterval(id);
  }, []);

  return now;
}
