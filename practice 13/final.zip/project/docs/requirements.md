# Smart Campus Room Availability Checker — Requirements (Practice 12, Task 02)

## Project description

Smart Campus is a web application that lets university students check whether a
classroom is available for a study session or event before making a booking.
Rooms are listed with their building, seat capacity, and blocked status; existing
bookings are stored in a database and shown on a day timeline. The student picks
a start time and a duration, and the application deterministically decides
whether the requested slot can be accepted.

## User story

> As a university student, I want to select a starting time and a duration and
> see immediately whether the classroom is available, so that I can plan my
> study session without clashing with existing bookings or blocked rooms.

The flow: the student opens the app, selects a room, enters a start time and a
duration in minutes, and presses "Check Availability". The application answers
with a clear available/unavailable verdict, a reason code, and a readable
message.

## Acceptance criteria

| ID | Criterion |
|---|---|
| AC1 | Starting time must be in the future (strictly after the current time). |
| AC2 | Duration must be greater than zero and at most 120 minutes. |
| AC3 | Requested slots overlapping an existing booking are unavailable. Adjacent (back-to-back) bookings are allowed. |
| AC4 | Blocked rooms are unavailable, regardless of the time slot. |
| AC5 | Availability checking must not change existing booking data. |
| AC6 | Invalid input must receive understandable feedback (never silence or a crash). |

## Inputs and outputs

**Inputs**

1. Start time (minutes since midnight, "HH:MM" in the UI).
2. Duration in minutes.
3. Blocked-room boolean.
4. Existing fictional bookings (each with a start and an end time).

**Outputs**

1. Availability boolean (`available`).
2. Reason code (see table below).
3. Visible user message (human-readable explanation).

## Reason codes

| Code | Meaning |
|---|---|
| `AVAILABLE` | The slot is accepted; no rule was violated. |
| `INVALID_START_TIME` | Start time is not strictly in the future. |
| `INVALID_DURATION` | Duration is zero, negative, or greater than 120 minutes. |
| `ROOM_BLOCKED` | The room is blocked for the requested slot. |
| `BOOKING_OVERLAP` | The slot overlaps an existing booking. |

## Booking rule (overlap formula)

A conflict exists when, and only when:

```
(start < booking.end) AND (end > booking.start)
```

where `start`/`end` describe the requested slot and `booking.start`/`booking.end`
describe an existing booking. Both comparisons are **strict**, so if the
requested slot merely touches an existing booking's boundary, the formula is
false and there is no conflict. That is why adjacent bookings are allowed: a
request for 11:00–11:30 against a booking ending at 11:00 yields
`11:00 < 11:00` → false, so the request is accepted.

## Applicability to future implementations

These requirements, the reason codes, the shared test fixture
(`shared-test-data.md`), and the eight test cases (`test-cases.md`) are
implementation-agnostic: any future implementation (a refactored checker, a
server-side validator, or a database-enforced rule set) can be validated by
running the same eight test cases against the same fixture.
