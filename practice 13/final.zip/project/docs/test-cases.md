# Test Cases (Practice 12, Task 02)

All eight cases run against the shared fixture in `docs/shared-test-data.md`:
test clock 09:00, room Engineering 101 (`eng-101`) not blocked, existing
fictional bookings 10:00–11:00 and 13:00–14:00.

## Test case table

| ID | Start | Duration | Room | Expected reason code | Expected verdict |
|---|---|---|---|---|---|
| T1 | 11:30 | 30 | not blocked | `AVAILABLE` | Available |
| T2 | 10:30 | 30 | not blocked | `BOOKING_OVERLAP` | Unavailable (overlaps 10:00–11:00) |
| T3 | 11:30 | 30 | blocked | `ROOM_BLOCKED` | Unavailable |
| T4 | 11:30 | 0 | not blocked | `INVALID_DURATION` | Validation error |
| T5 | 11:30 | 121 | not blocked | `INVALID_DURATION` | Validation error |
| T6 | 08:30 | 30 | not blocked | `INVALID_START_TIME` | Validation error (start before current time 09:00) |
| T7 | 11:00 | 30 | not blocked | `AVAILABLE` | Available (adjacent to booking ending 11:00) |
| T8 | 11:30 | 30 | not blocked | `AVAILABLE` | Existing booking data unchanged after the check (AC5) |

The human-readable "visible user message" for each verdict is produced by the
checker; the test asserts the message is a non-empty string so AC6 (understandable
feedback) is verified for every case, including rejections.

## Execution instructions

From the project root:

```
npm test          # runs every Vitest suite, including Practice 12
npx vitest run src/lib/practice12.test.ts   # runs only these eight cases
```

Each case maps to one `it(...)` block in `src/lib/practice12.test.ts`, named
`T1` … `T8`. Results appear in the terminal with the same IDs.
