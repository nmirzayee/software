# Shared Test Data (Practice 12, Task 02)

This fixture is deterministic and separate from application data. It exists only
inside `src/lib/practice12.test.ts`; no database table, booking record, or
application source file was created or changed to produce it.

## Test clock

| Item | Value |
|---|---|
| Test current time | 09:00 (540 minutes since midnight) |

The application's fictional clock constant lives in `src/sampleData.ts`
(`CURRENT_TIME`); the fixture uses its own value so the tests stay independent
of any future change to that constant.

## Room information

One existing fictional room from the project is reused:

| Field | Value |
|---|---|
| id | `eng-101` |
| name | Engineering 101 |
| building | Block A |
| capacity | 40 seats |
| blocked in fixture | `false` (overridden to `true` for test T3 only) |

## Existing fictional bookings

Both bookings belong to Engineering 101 within the fixture only:

| Title | Start | End | Minutes |
|---|---|---|---|
| Study group session | 10:00 | 11:00 | 600–660 |
| Seminar practice | 13:00 | 14:00 | 780–840 |

## Fixture explanation

The fixture builds a fresh parameter object for every test case (a helper
equivalent to the `makeInput` pattern already used in `availability.test.ts`):
current time 09:00, room not blocked, and the two bookings above. Each case
passes `start` and `duration`; the test converts the duration to
`end = start + duration` before calling the existing deterministic checker.
Because the object is rebuilt per test and the checker is a pure function, no
test can observe or affect another test's data, and the application database is
never touched.
